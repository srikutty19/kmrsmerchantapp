
var krms_config ={			
	'ApiUrl' : "http://kdboys.chiarro.com/merchantapp/api",	
	'DialogDefaultTitle' : "KDB MERCHANT",
	'pushNotificationSenderid' : "YOUR_ANDROID_PUSH_PROJECT_ID",
	'APIHasKey' : "ef65011e2b65508fa173e1549e56d1e8"
};